-- ================================================================
-- SCRIPT SQL TEST SISTEMA NEWS AVANZATO
-- Kiosk HR v2.3.0 - Adeverente
-- Data: 21 Gennaio 2026
-- ================================================================

USE [Employee]
GO

PRINT '=========================================='
PRINT 'INSERIMENTO NEWS DI TEST'
PRINT '=========================================='
PRINT ''

-- ================================================================
-- 1. NEWS BREVE (< 200 caratteri)
-- Test: Refresh rapido (8 secondi)
-- ================================================================

PRINT '1. Inserimento NEWS BREVE...'

INSERT INTO [dbo].[News] 
    (EmployeerId, StartNews, EndNews, News, Publisher, IsMandatory)
VALUES 
    (2, 
     GETDATE(), 
     DATEADD(DAY, 7, GETDATE()), 
     'Domani chiusura mensa dalle 14:00 alle 16:00 per pulizie straordinarie.', 
     'Facility Manager', 
     0)

PRINT '   ✓ News breve inserita (Refresh: 8 secondi)'
PRINT ''

-- ================================================================
-- 2. NEWS MEDIA (200-500 caratteri)
-- Test: Refresh medio (12 secondi)
-- ================================================================

PRINT '2. Inserimento NEWS MEDIA...'

INSERT INTO [dbo].[News] 
    (EmployeerId, StartNews, EndNews, News, Publisher, IsMandatory)
VALUES 
    (2, 
     GETDATE(), 
     DATEADD(DAY, 7, GETDATE()), 
     'RIUNIONE GENERALE - Giovedì 23 gennaio alle ore 10:00 si terrà la riunione mensile in sala conferenze. La partecipazione è obbligatoria per tutti i dipendenti. Argomenti: obiettivi Q1 2026, nuove procedure di sicurezza, aggiornamenti organizzativi. Si prega di portare badge e materiale per appunti.', 
     'HR Department', 
     0)

PRINT '   ✓ News media inserita (Refresh: 12 secondi)'
PRINT ''

-- ================================================================
-- 3. NEWS LUNGA (> 500 caratteri)
-- Test: Auto-scrolling + Refresh esteso (20+ secondi)
-- ================================================================

PRINT '3. Inserimento NEWS LUNGA con SCROLLING...'

INSERT INTO [dbo].[News] 
    (EmployeerId, StartNews, EndNews, News, Publisher, IsMandatory)
VALUES 
    (2, 
     GETDATE(), 
     DATEADD(DAY, 7, GETDATE()), 
     'COMUNICAZIONE IMPORTANTE - AGGIORNAMENTO PROCEDURE AZIENDALI

A partire dal 1° febbraio 2026 entreranno in vigore le nuove procedure di sicurezza e qualità.

PRINCIPALI NOVITÀ:

1. BADGE E ACCESSI
   - Obbligo di esposizione badge in area visibile durante tutto l''orario di lavoro
   - Registrazione ingresso/uscita obbligatoria tramite tornelli elettronici
   - Accesso alle aree produttive consentito solo con DPI completi e certificati
   - Controlli random a campione da parte del servizio sicurezza

2. FORMAZIONE OBBLIGATORIA
   - Corso sicurezza sul lavoro: 15 febbraio 2026 ore 09:00 (Aula Magna)
   - Corso qualità ISO 9001:2015: 22 febbraio 2026 ore 14:00 (Sala Training)
   - Corso primo soccorso e antincendio: 1 marzo 2026 ore 10:00 (Area Esterna)
   - Attestato di partecipazione obbligatorio per tutti i dipendenti

3. NUOVI ORARI SERVIZI
   - Mensa primo turno: 12:00 - 13:00
   - Mensa secondo turno: 13:00 - 14:00
   - Pausa caffè mattutina: 10:00 - 10:15
   - Pausa caffè pomeridiana: 15:30 - 15:45

4. POLICY SMART WORKING
   - Richiesta tramite portale HR con almeno 48 ore di anticipo
   - Massimo 2 giorni a settimana per dipendente
   - Presenza obbligatoria durante le riunioni settimanali di reparto

5. PARCHEGGI
   - Parcheggio Ovest: riservato ai dipendenti con badge
   - Parcheggio Est: per visitatori e fornitori
   - Parcheggio Sud: riservato a disabili e famiglie

Per ulteriori informazioni e chiarimenti, contattare l''ufficio HR Department.

La direzione ringrazia per la collaborazione.', 
     'Management', 
     0)

PRINT '   ✓ News lunga inserita (Scrolling automatico + Refresh: 20+ secondi)'
PRINT ''

-- ================================================================
-- 4. NEWS MANDATORY (Priorità alta)
-- Test: Stile rosso/arancione e priorità assoluta
-- ================================================================

PRINT '4. Inserimento NEWS MANDATORY (IMPORTANTE)...'

INSERT INTO [dbo].[News] 
    (EmployeerId, StartNews, EndNews, News, Publisher, IsMandatory)
VALUES 
    (2, 
     GETDATE(), 
     DATEADD(DAY, 3, GETDATE()), 
     '⚠️ ATTENZIONE - PROVA EVACUAZIONE ANTINCENDIO ⚠️

Venerdì 24 gennaio alle ore 15:00 si terrà la prova di evacuazione antincendio obbligatoria.

TUTTI I DIPENDENTI devono partecipare.

PROCEDURA:
1. Al suono della sirena interrompere immediatamente il lavoro
2. Spegnere macchinari e computer
3. Seguire le vie di fuga indicate
4. Radunarsi nel punto di raccolta esterno

NON usare ascensori. Aiutare colleghi in difficoltà.', 
     'Safety Department', 
     1)  -- IsMandatory = 1

PRINT '   ✓ News mandatory inserita (PRIORITÀ ALTA - stile rosso/arancione)'
PRINT ''

-- ================================================================
-- 5. NEWS CON ELENCHI E FORMATTAZIONE
-- Test: Word wrap e formattazione testo
-- ================================================================

PRINT '5. Inserimento NEWS con FORMATTAZIONE...'

INSERT INTO [dbo].[News] 
    (EmployeerId, StartNews, EndNews, News, Publisher, IsMandatory)
VALUES 
    (2, 
     GETDATE(), 
     DATEADD(DAY, 14, GETDATE()), 
     'EVENTI AZIENDALI FEBBRAIO 2026

📅 10 Feb - Team Building presso Villa Laguna
   Partecipazione gratuita
   Iscrizioni entro il 5 febbraio tramite portale HR

🎂 15 Feb - Festa compleanno dipendenti Q1
   Ore 16:00 in sala ricreativa
   Buffet a cura dell''azienda

🏆 20 Feb - Premiazione "Dipendente del mese"
   Cerimonia ore 11:00 in sala conferenze
   Premiazione con bonus e targa

🍕 28 Feb - Pizza party di fine mese
   Ore 18:30 area esterna (solo se bel tempo)
   In caso di pioggia: sala mensa

Per INFO: hr@company.com', 
     'HR Department', 
     0)

PRINT '   ✓ News formattata inserita'
PRINT ''

-- ================================================================
-- RIEPILOGO NEWS INSERITE
-- ================================================================

PRINT '=========================================='
PRINT 'RIEPILOGO NEWS INSERITE'
PRINT '=========================================='

SELECT 
    NewId,
    CAST(StartNews AS DATE) as DataInizio,
    CAST(EndNews AS DATE) as DataFine,
    LEFT(News, 60) + '...' as AnteprimaNews,
    Publisher,
    CASE IsMandatory 
        WHEN 1 THEN 'SÌ (PRIORITÀ ALTA)'
        ELSE 'No'
    END as Obbligatoria,
    LEN(News) as LunghezzaTesto,
    CASE 
        WHEN LEN(News) > 500 THEN '20+ sec + scrolling'
        WHEN LEN(News) > 200 THEN '12 sec'
        ELSE '8 sec'
    END as TempoRefresh
FROM [Employee].[dbo].[News]
WHERE GETDATE() BETWEEN StartNews AND EndNews
ORDER BY IsMandatory DESC, StartNews ASC

PRINT ''
PRINT '=========================================='
PRINT 'QUERY DI VERIFICA E MONITORING'
PRINT '=========================================='
PRINT ''

-- Query 1: News attualmente visualizzabili
PRINT '-- Query 1: News attualmente visualizzabili'
PRINT ''

SELECT 
    NewId,
    News,
    Publisher,
    IsMandatory,
    DATEDIFF(DAY, GETDATE(), EndNews) as GiorniRimanenti,
    LEN(News) as Lunghezza
FROM [Employee].[dbo].[News]
WHERE GETDATE() BETWEEN StartNews AND EndNews
ORDER BY IsMandatory DESC, StartNews ASC

PRINT ''
PRINT '-- Query 2: Controlla tabella KiosRequestes (stampe news)'
PRINT ''

SELECT TOP 10
    KiosRequestId,
    RequestDate,
    IpRequest,
    RequestBy,
    RequestWhat,
    CASE Executed 
        WHEN 1 THEN 'Completata'
        ELSE 'In attesa'
    END as StatoStampa
FROM [Employee].[dbo].[KiosRequestes]
WHERE RequestWhat LIKE 'Stampa News%'
ORDER BY RequestDate DESC

PRINT ''
PRINT '=========================================='
PRINT 'TEST COMPLETATO CON SUCCESSO!'
PRINT '=========================================='
PRINT ''
PRINT 'Prossimi passi:'
PRINT '1. Apri http://localhost:5000 nel browser'
PRINT '2. Osserva il comportamento delle news:'
PRINT '   - News breve: refresh ogni 8 secondi'
PRINT '   - News media: refresh ogni 12 secondi'
PRINT '   - News lunga: scrolling automatico + refresh 20+ sec'
PRINT '   - News mandatory: stile rosso/arancione prioritario'
PRINT '3. Clicca su una news per testarela stampa'
PRINT '4. Verifica registrazione in KiosRequestes'
PRINT ''

GO

-- ================================================================
-- CLEANUP (Decommentare solo se vuoi rimuovere le news di test)
-- ================================================================

/*
PRINT 'Rimozione news di test...'

DELETE FROM [Employee].[dbo].[News]
WHERE Publisher IN ('Facility Manager', 'HR Department', 'Management', 'Safety Department')
  AND StartNews >= CAST(GETDATE() AS DATE)

PRINT 'News di test rimosse.'
*/
